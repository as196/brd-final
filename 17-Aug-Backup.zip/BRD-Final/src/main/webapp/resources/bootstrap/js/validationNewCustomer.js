function Validate() 
{
	if(ValidateNewCustomerCode()) 
	{
		if(ValidateNewCustomerName()) 
		{
			if(ValidateNewCustomerPinCode())
			{
			   if(CheckEmail())
			    {
				 if(ValidateNewCustomerPhone())
				   {   
					  return true;
				   }
			    }
			}
		}
		return false;
	} 
	else 
	{
		return false;
	}
}

function ValidateNewCustomerCode() 
{
	var value = document.forms["NewCustomer"]["customerCode"].value;
	var regex = /^\d+$/;
	if (value.match(regex)) 
	{
		if(value.length<=10)
		{
			return true;
		}
		else
		{
			alert("Customer Code should be less than 10 characters.");
		    document.forms["NewCustomer"]["customerCode"].focus();
		    return false;
		}
	} 
	else 
	{
		alert("Customer Code should be only in numerics without spaces.");
		document.forms["NewCustomer"]["customerCode"].focus();
		return false;
	}
}

function ValidateNewCustomerName() 
{
	var value = document.forms["NewCustomer"]["customerName"].value;
	var regex = /^[A-Z a-z]+$/;
	if (value.match(regex)) 
	{
		if(value.length<=30)
		{
		    return true;
	    }
	    else
	    {
	    	alert("Customer Name should be less than 30 characters.");
		    document.forms["NewCustomer"]["customerName"].focus();
		    return false;

	    }
	} 
	else 
	{
		alert("Customer Name should be only in alphabets.");
		document.forms["NewCustomer"]["customerName"].focus();
		return false;
	}
}

function ValidateNewCustomerPhone() 
{
	var value = document.forms["NewCustomer"]["contactNumber"].value;
	var regex = /^\d+$/;
	if (value.match(regex)) 
	{
		if(value.length<=20)
		{
			return true;
		}
		else
		{
			alert("Customer Contact Number should be less than 20 characters.");
		    document.forms["NewCustomer"]["contactNumber"].focus();
		    return false;
		}
	} 
	else 
	{
		alert("Phone Number may only contain numbers.");
		document.forms["NewCustomer"]["contactNumber"].focus();
		return false;
	}
}

function CheckEmail() 
{

	var emailID=document.forms["NewCustomer"]["email"].value;
	atpos = emailID.indexOf("@");
    dotpos = emailID.lastIndexOf(".");
    if (atpos < 1 || ( dotpos - atpos < 2 )) 
    {
       alert("Please enter correct email ID.");
       document.forms["NewCustomer"]["email"].focus();
       return false;
    }
    else if (emailID.length>100) 
    {
    	alert("Customer Email should be less than less than 100 characters.")
    	document.forms["NewCustomer"]["email"].focus();
    	return false;
    }
    else
    	{
    	return true;
    	}
}

function ValidateNewCustomerPinCode()
{
	var pinCode=document.forms["NewCustomer"]["pinCode"].value;
	var regex = /^[0-9]+$/;
	if (pinCode.match(regex)) 
	{
		if(pinCode.length == 6)
		{
			return true;
		}
		else
		{
		    alert("Customer Pin Code should of 6 characters.")
    	    document.forms["NewCustomer"]["pinCode"].focus();
    	    return false;	
		}
	} 
	else 
	{
		alert("Pin Code may only contain numbers.");
		document.forms["NewCustomer"]["pinCode"].focus();
		return false;
	}
}

function Delete() 
{
    confirm("Sure, you want to delete?");
}