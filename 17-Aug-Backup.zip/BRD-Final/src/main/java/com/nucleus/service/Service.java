package com.nucleus.service;

import java.util.List;

import org.springframework.security.access.annotation.Secured;

import com.nucleus.model.Customer;
import com.nucleus.model.User;

public interface Service
{
	@Secured("ROLE_ADMIN")
	public boolean createNewUser(User users);
	@Secured("ROLE_ADMIN")
	public boolean enableDisable(String userName, String choice);
	@Secured({"ROLE_ADMIN, ROLE_USER"})
	public User findUser(String userName);
	@Secured("ROLE_USER")
	public boolean createNewCustomer(Customer customers);
	@Secured("ROLE_USER")
	public List<Customer> viewAllCustomers();
	@Secured("ROLE_USER")
	public List<Customer> viewCustomerSingle(String customerCodeOrName);
	@Secured("ROLE_USER")
	public boolean deleteCustomer(Customer customers);
	@Secured("ROLE_USER")
	public Customer findCustomer(Integer customerCode);
	@Secured("ROLE_USER")
	public boolean updateCustomer(Customer customers);
}
