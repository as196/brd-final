package com.nucleus.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import com.nucleus.dao.CustomerDao;
import com.nucleus.dao.UserDao;
import com.nucleus.model.Customer;
import com.nucleus.model.User;

@org.springframework.stereotype.Service @Transactional
public class ServiceImpl implements Service
{
	@Autowired
	User users;
	
	@Autowired
	Customer customers;
	
	@Autowired
	UserDao userDao;
	
	@Autowired
	CustomerDao customerDao;
	
	@Override
	public boolean enableDisable(String userName, String choice)
	{
		return userDao.enableDisable(userName, choice);
	}
	
	@Override
	public boolean createNewUser(User users)
	{
		return userDao.createNewUser(users);
	}
	
	@Override
	public User findUser(String userName)
	{
		return userDao.findUser(userName);
	}

	@Override
	public boolean createNewCustomer(Customer customers)
	{
		return customerDao.createNewCustomer(customers);
	}
	
	@Override
	public List<Customer> viewAllCustomers()
	{
		return customerDao.viewAllCustomers();
	}
	
	@Override
	public List<Customer> viewCustomerSingle(String customerCodeOrName)
	{
		return customerDao.viewCustomerSingle(customerCodeOrName);
	}

	@Override
	public boolean deleteCustomer(Customer customers)
	{
		return customerDao.deleteCustomer(customers);
	}

	@Override
	public Customer findCustomer(Integer customerCode)
	{
		return customerDao.findCustomer(customerCode);
	}

	@Override
	public boolean updateCustomer(Customer customers)
	{
		return customerDao.updateCustomer(customers);
	}

}
