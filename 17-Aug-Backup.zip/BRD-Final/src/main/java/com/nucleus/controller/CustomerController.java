package com.nucleus.controller;


import java.sql.Date;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.nucleus.model.Customer;
import com.nucleus.service.Service;

@Controller
public class CustomerController
{
	@Autowired
	Customer customers;
	
	@Autowired
	Service service;
	
	public static final String PAGE = "MessagePrintCustomer";
	public static final String MESSAGE = "message";
	public static final String REDIRECT = "redirect:/";
	public static final String MSG_SOMETHING_WENT_WRONG = "Something Went Wrong, Please Login Again. ";
	Date persistRegistrationDate;
	String persistCreatedBy;
	int i=0;
	
	/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
	@RequestMapping("/NewCustomer")
	public ModelAndView newRedirect(Customer customers)
	{
		return new ModelAndView("NewCustomer");
	}
	
	@RequestMapping("/newCustomerSubmit")
	public ModelAndView newSubmitRedirect(@Valid Customer customers,BindingResult bindingResult,Authentication authentication)
	{
		if(bindingResult.hasErrors())
		{
			return new ModelAndView("NewCustomer");
		}
		
		customers.setCreatedBy(authentication.getName());
		
		if (service.findCustomer(customers.getCustomerCode()) != null)
		{
			return new ModelAndView(PAGE, MESSAGE, "Customer With Same Customer Code Already Exsists");
		}
		else
		{
			if (service.createNewCustomer(customers))
			{
				return new ModelAndView(PAGE, MESSAGE, "Data Submitted Successfully");
			}
			else
			{
				return new ModelAndView(PAGE, MESSAGE, "Data Submission Failed");
			}
		}
		
	}
	
	/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
	
	@RequestMapping("/viewAll")
	public ModelAndView viewAllRedirect(Customer customers)
	{
		return new ModelAndView("ViewAll","customer",service.viewAllCustomers());
	}
	
	/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
	@RequestMapping("/ViewByCode")
	public ModelAndView viewByCodeRedirect(Customer customers)
	{
		return new ModelAndView("EnterCodeToView");
	}
	
	@RequestMapping("/viewByCodeSubmit")
	public ModelAndView viewByCodeRedirect2(Customer customers,@RequestParam("customerCodeOrName") String customerCodeOrName)
	{
		List<Customer> customer = service.viewCustomerSingle(customerCodeOrName);
		if(!customer.isEmpty())
		{
			return new ModelAndView("ViewByCodeOrName","customer",customer);
		}
		else
		{
			return new ModelAndView(PAGE, MESSAGE, "No Customer Exists With That Code Or Name");
		}
		
	}
	
	/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
	
	@RequestMapping("/Delete")
	public ModelAndView deleteRedirect(Customer customers)
	{
		return new ModelAndView("EnterCodeToDelete");
	}
	
	@RequestMapping("/deleteCodeSubmit")
	public ModelAndView deleteSubmit(Customer customers,@RequestParam("customerCodeToDelete") String customerCodeToDelete)
	{
		Integer code;
		try
		{
			code = Integer.parseInt(customerCodeToDelete);
		}
		catch (Exception e)
		{
			return new ModelAndView(PAGE, MESSAGE, "No Customer Exists With That Customer Code");
		}
		
		try
		{
			List<Customer> customer = service.viewCustomerSingle(code.toString());
			if(!customer.isEmpty())
			{
				if(service.deleteCustomer(service.findCustomer(code)))
				{
					return new ModelAndView(PAGE,MESSAGE,"Customer Deleted Successfully");
				}
				else
				{
					return new ModelAndView(PAGE,MESSAGE,"Customer Delete Operation Failed");
				}
			}
			else
			{
				return new ModelAndView(PAGE, MESSAGE, "No Customer Exists With That Code");
			}
		}
		catch (Exception e) 
		{
			return new ModelAndView(PAGE, MESSAGE, "Customer Code Can Not Be A Blank Space");
		}
		
		
	}
	
	/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
	
	@RequestMapping("/Update")
	public ModelAndView updateRedirect(Customer customers)
	{
		return new ModelAndView("EnterCodeToUpdate");
	}
	
	@RequestMapping("/updateCodeSubmit")
	public ModelAndView updateRedirect2(@RequestParam("customerCode") String customerCode1)
	{
		Integer customerCode;
		
		try
		{
			customerCode = Integer.parseInt(customerCode1);
			customers=service.findCustomer(customerCode);
			
			if (customers != null)
			{
				persistRegistrationDate = customers.getRegistrationDate();
				persistCreatedBy = customers.getCreatedBy();

				return new ModelAndView("Update", "customer", customers);
			} 
			else 
			{
				return new ModelAndView("redirect:notFound");
			}
		}
		catch (Exception e)
		{
			return new ModelAndView("redirect:notFound");
		}
		
	}
	
	@RequestMapping("/updateCustomerSubmit")
	public ModelAndView updateSubmit(Customer customers)
	{
		customers.setRegistrationDate(persistRegistrationDate);
		customers.setCreatedBy(persistCreatedBy);
		
		if(service.updateCustomer(customers))
		{
			return new ModelAndView(PAGE,MESSAGE,"Customer Data Updated Successfully");
		}
		else
		{
			return new ModelAndView(PAGE,MESSAGE,"Customer Data Updating Failed");
		}
	}
	
	@RequestMapping("/notFound")
	public ModelAndView notFound(Customer customers)
	{
		return new ModelAndView(PAGE, MESSAGE, "No Customer Exists With That Code");
	}
	/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
}
