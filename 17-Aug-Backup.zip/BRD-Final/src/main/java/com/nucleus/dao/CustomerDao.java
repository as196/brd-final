package com.nucleus.dao;

import java.util.List;

import com.nucleus.model.Customer;

public interface CustomerDao
{
	public boolean createNewCustomer(Customer customers);
	public List<Customer> viewAllCustomers();
	public List<Customer> viewCustomerSingle(String customerCodeOrName);
	public boolean deleteCustomer(Customer customers);
	public Customer findCustomer(Integer customerCode);
	public boolean updateCustomer(Customer customers);
}
