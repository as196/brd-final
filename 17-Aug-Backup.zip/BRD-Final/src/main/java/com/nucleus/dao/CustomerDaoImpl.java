package com.nucleus.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.nucleus.model.Customer;

@Repository
public class CustomerDaoImpl implements CustomerDao
{
	@Autowired
	Customer customers;
	
	@PersistenceContext private EntityManager entityManager;
	
	
	public boolean createNewCustomer(Customer customers)
	{
		long millis=System.currentTimeMillis();
		java.sql.Date date=new java.sql.Date(millis);
		
		customers.setRegistrationDate(date);
				
		try
		{
			entityManager.persist(customers);
			return true;
		}
		catch (Exception e)
		{
			return false;
		}		
	}
	
	@SuppressWarnings("unchecked")
	public List<Customer> viewAllCustomers()
	{
		javax.persistence.Query query = entityManager.createQuery("from Customer"); //.setFirstResult(1).setMaxResults(5)
		return query.getResultList();
	}
	
	@SuppressWarnings("unchecked")
	public List<Customer> viewCustomerSingle(String customerCodeOrName)
	{
		List<Customer> list=null;
		try
		{
			int customerCode = Integer.parseInt(customerCodeOrName);
			javax.persistence.Query query = entityManager.createQuery("from Customer c where c.customerCode=?");
			query.setParameter(1, customerCode);
			return query.getResultList();
		}
		catch (Exception e)
		{
			try
			{
				javax.persistence.Query query = entityManager.createQuery("from Customer c where c.customerName=?");
				query.setParameter(1, customerCodeOrName);
				return query.getResultList();
			}
			catch (Exception e1) 
			{
				return list;
			}
		}
	}
	
	public boolean deleteCustomer(Customer customers)
	{
	
		try 
		{
			javax.persistence.Query query = entityManager.createQuery("delete from Customer c where c.customerCode=?");
			query.setParameter(1, customers.getCustomerCode());
			query.executeUpdate();
			return true;
		}
		catch (Exception e) 
		{
			return false;
		}
		
	}
	
	public Customer findCustomer(Integer customerCode)
	{
		try
		{
		javax.persistence.Query query = entityManager.createQuery("from Customer c where c.customerCode=?");
		query.setParameter(1, customerCode);
		return (Customer) query.getSingleResult();
		}
		catch (Exception e) 
		{
			return null;
		}
	}
	
	public boolean updateCustomer(Customer customers)
	{
		long millis=System.currentTimeMillis();
		java.sql.Date date=new java.sql.Date(millis);
		
		customers.setModifiedDate(date);
		
		try
		{
		    entityManager.merge(customers);
			return true;
		}
		catch (Exception e)
		{
			return false;
		}		
	}	
}
