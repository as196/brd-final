package com.nucleus.model;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.Range;
import org.springframework.stereotype.Component;

@Component @Entity @Table(name="karizma_spring_customer")
public class Customer
{
	@Id @NotNull @Range(min = 1, max = 999999999) @Column(name="CUSTOMER_CODE")
	private Integer customerCode;
	@Pattern(regexp="^[A-Z a-z]*$") @NotEmpty @Length(max=30) @Column(name="CUSTOMER_NAME")
	private String customerName;
	@NotEmpty @Length(max=100) @Column(name="CUSTOMER_ADDRESS")
	private String customerAddr;
	@Pattern(regexp="[0-9]*") @Length(min = 6, max = 6) @Column(name="CUSTOMER_PINCODE")
	private String pinCode;
	@Email @NotEmpty @Length(max=100) @Column(name="CUSTOMER_EMAIL")
	private String email;
	@Pattern(regexp="[0-9]*") @Length(max=20) @Column(name="CUSTOMER_CONTACT_NUMBER")
	private String contactNumber;
	@Column(name="CUSTOMER_REGISTRATION_DATE")
	private Date registrationDate;
	@Column(name="CUSTOMER_CREATED_BY")
	private String createdBy;
	@Column(name="CUSTOMER_MODIFIED_DATE")
	private Date modifiedDate;
	
	//getters-setters
	
	public Integer getCustomerCode() {
		return customerCode;
	}
	public void setCustomerCode(Integer customerCode) {
		this.customerCode = customerCode;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getCustomerAddr() {
		return customerAddr;
	}
	public void setCustomerAddr(String customerAddr) {
		this.customerAddr = customerAddr;
	}
	public String getPinCode() {
		return pinCode;
	}
	public void setPinCode(String pinCode) {
		this.pinCode = pinCode;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}
	public Date getRegistrationDate() {
		return registrationDate;
	}
	public void setRegistrationDate(Date registrationDate) {
		this.registrationDate = registrationDate;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Date getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
		
}
